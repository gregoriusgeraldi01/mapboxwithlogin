<?php
    include('db.php');
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Form Login and Register</title>
    <link rel="stylesheet" href="style.css">

</head>
<body>
    <h1>Welcome User</h1>
    <a href="login.php">Logout</a>
</body>
</html>  