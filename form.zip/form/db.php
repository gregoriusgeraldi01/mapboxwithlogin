<?php
    $con = mysqli_connect("localhost", "root", "", "register") or die(mysql_error());
?>

